'use client'
import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <Card className="w-full max-w-md shadow-lg">
        <img src="/logo.png" alt="Deekle Logo" className="h-12 mx-auto mb-4" />
        <CardHeader>
          <CardTitle className="text-2xl text-center text-purple-700">Welcome Back</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Button className="w-full bg-purple-700 hover:bg-purple-800 text-white">Login</Button>
        </CardContent>
      </Card>
    </div>
  )
}