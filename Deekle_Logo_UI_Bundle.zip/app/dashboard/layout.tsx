import Link from "next/link"
import { ReactNode } from "react"

const navItems = [
  { name: "Overview", href: "/dashboard" },
  { name: "Compliance", href: "/dashboard/compliance" },
  { name: "Courses", href: "/dashboard/courses" },
  { name: "Analytics", href: "/dashboard/analytics" },
  { name: "Messages", href: "/dashboard/messages" },
  { name: "Study Generator", href: "/dashboard/study-generator" }
]

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex bg-gray-50 text-gray-800">
      <aside className="w-64 bg-white shadow-lg px-4 py-6 space-y-4 border-r">
        <img src="/logo.png" alt="Deekle Logo" className="h-10 mb-6" />
        <nav className="flex flex-col space-y-2">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="text-sm px-3 py-2 rounded hover:bg-purple-100 hover:text-purple-800 transition"
            >
              {item.name}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-6">
        {children}
      </main>
    </div>
  )
}