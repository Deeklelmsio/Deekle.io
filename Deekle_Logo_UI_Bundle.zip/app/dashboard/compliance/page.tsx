'use client'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, FileText, Calendar, Award, Filter, Download } from "lucide-react"

const complianceStats = [
  {
    title: "Overall Compliance",
    value: "87%",
    description: "Target: 100%",
    icon: <Shield className="h-5 w-5 text-purple-700" />,
  },
  {
    title: "Required Trainings",
    value: "12",
    description: "8 completed, 4 pending",
    icon: <FileText className="h-5 w-5 text-purple-700" />,
  },
  {
    title: "Expiring Soon",
    value: "3",
    description: "Within next 30 days",
    icon: <Calendar className="h-5 w-5 text-purple-700" />,
  },
  {
    title: "Certifications",
    value: "5",
    description: "All current",
    icon: <Award className="h-5 w-5 text-purple-700" />,
  },
]

export default function CompliancePage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Compliance Training</h1>
          <p className="text-sm text-gray-500">Track and manage compliance across your teams</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {complianceStats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              {stat.icon}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}